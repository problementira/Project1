package com.cg.service;

import java.util.List;

import com.cg.entity.Accounts;
import com.cg.entity.BusinessSegment;
import com.cg.entity.Policy;
import com.cg.entity.PolicyDetails;
import com.cg.entity.PolicyQuestions;
import com.cg.entity.UserRole;

public interface IInsuranceQuoteService 
{
 public int login(String username,String  password) throws Exception;
 public void addUser(UserRole user) throws Exception;
 public void createAccount(Accounts account) throws Exception;
	public void createPolicy(Policy policy) throws Exception;
	public PolicyDetails returnPolicyDetails(int policynumber) throws Exception;
	public void setPolicyDetails(PolicyDetails policydetails) throws Exception;
	public BusinessSegment returnBusinessSegment(int businessid) throws Exception;
	public void setBusinessSegment(BusinessSegment businesssegment) throws Exception;
	public List<PolicyQuestions> returnQuestions(String businessid) throws Exception;
	public List<Policy> returnPolicy(long accountnumber) throws Exception;
}
