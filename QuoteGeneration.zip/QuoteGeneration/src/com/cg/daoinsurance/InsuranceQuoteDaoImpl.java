package com.cg.daoinsurance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.print.attribute.standard.PrinterIsAcceptingJobs;

import com.cg.entity.Accounts;
import com.cg.entity.BusinessSegment;
import com.cg.entity.Policy;
import com.cg.entity.PolicyDetails;
import com.cg.entity.PolicyQuestions;
import com.cg.entity.UserRole;
import com.cg.exception.InsuranceException;
import com.cg.utility.DBUtil;;

public class InsuranceQuoteDaoImpl implements IInsuranceQuoteDao {

	Connection con=null;
	@Override
	public int login(String username,String password) throws InsuranceException {
		int rolecode=0;
		ResultSet rs=null;
		try{
		con=DBUtil.getConnection();
		String qry="select role_code,password from user_role where user_name=?";
		PreparedStatement pstmt=con.prepareStatement(qry);
		pstmt.setString(1, username);
		rs=pstmt.executeQuery();
		boolean flag=rs.next();
		if(flag)
		{
			if(!rs.getString("password").equals(password))
			{
			throw new InsuranceException("Wrong User Name and password");
			}
			rolecode=rs.getInt("role_code");
			con.close();
		}
		else{
			throw new InsuranceException();
		}
		
			
		}catch(SQLException e)
		{ 
			e.printStackTrace();
			
		}
		return rolecode;
		}


	@Override
	public void addUser(UserRole user) throws InsuranceException{
		con=DBUtil.getConnection();
		String qry="insert into user_role values(?,?,?)";
		String username=user.getUserName();
		String password=user.getPassWord();
		int rolecode=user.getRoleCode();
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement(qry);
		
		pstmt.setString(1, username);
		pstmt.setString(2, password);
		pstmt.setInt(3, rolecode);
		int n=pstmt.executeUpdate();
		if(n==0){
			throw new InsuranceException("UserName Already exist");
		}
		
		con.close();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}

	@Override
	public void createAccount(Accounts account) throws InsuranceException{
		con=DBUtil.getConnection();
		String qry="insert into accounts values(?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement(qry);
		
		pstmt.setLong(1, account.getAccountNumber());
		pstmt.setString(2, account.getInsuredName());
		pstmt.setString(3, account.getInsuredStreet());
		pstmt.setString(4, account.getInsuredCity());
		pstmt.setString(5, account.getInsuredState());
		pstmt.setInt(6, account.getInsuredZip());
		pstmt.setString(7, account.getBusinessSegment());
		
		pstmt.setString(8, account.getUserName());
		int n=pstmt.executeUpdate();
		if(n==0){
			throw new InsuranceException();
		}
		else
		{   
			String user=account.getUserName();
			String qry1="select role_code from user_role where user_name=?";
			pstmt = con.prepareStatement(qry1);
			pstmt.setString(1,user);
			ResultSet rs=pstmt.executeQuery();
			rs.next();
			int role=rs.getInt("role_code");
			if(role==3)
			{
				qry1="update user_role set role_code=? where user_name=?";
				pstmt = con.prepareStatement(qry1);
				pstmt.setInt(1, 4);
				pstmt.setString(2,user);
				pstmt.executeUpdate();
			}
		}
		con.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
			throw new InsuranceException();
		}
	}

	@Override
	public void createPolicy(Policy policy) throws Exception{
		
		con=DBUtil.getConnection();
		String qry="insert into policy values(?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(qry);
		pstmt.setLong(1, policy.getPolicyNumber());
		pstmt.setDouble(2, policy.getPolicyPremium());
		pstmt.setLong(3, policy.getAccountnumber());
		int n=pstmt.executeUpdate();
		if(n==0){
			throw new InsuranceException(" Not Inserted");
		}
		con.close();
		
	}

	@Override
	public PolicyDetails returnPolicyDetails(int policynumber) throws Exception{
		con=DBUtil.getConnection();
		String qry="select policy_number,question_id,answer from policy_details where policy_number=?";
		PreparedStatement pstmt=con.prepareStatement(qry);
		pstmt.setInt(1, policynumber);
		ResultSet rst=pstmt.executeQuery();
		boolean flag=rst.next();
		con.close();
		if(flag==false){
			throw new InsuranceException(" Not found");
		}
		else{
			PolicyDetails policydetail=new PolicyDetails(rst.getLong(1),rst.getString(2),rst.getString(3));
			return policydetail;
		}
		
	}

	@Override
	public void setPolicyDetails(PolicyDetails policydetails) throws Exception{
		con=DBUtil.getConnection();
		String qry="insert into policy_details values(?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(qry);
		pstmt.setLong(1, policydetails.getPolicyNumber());
		pstmt.setString(2, policydetails.getQuestionId());
		pstmt.setString(3, policydetails.getAnswer());
		int n=pstmt.executeUpdate();
		con.close();
		if(n==0){
			throw new InsuranceException(" Not Inserted ");
		}
		
	}

	@Override
	public BusinessSegment returnBusinessSegment(int businessid) throws Exception{
		
		con=DBUtil.getConnection();
		String qry="select bus_seg_id,bus_seg_name from business_segment where bus_seg_id=?";
		PreparedStatement pstmt=con.prepareStatement(qry);
		pstmt.setInt(1, businessid);
		ResultSet rst=pstmt.executeQuery();
		boolean flag=rst.next();
		if(flag==false){
			throw new InsuranceException(" Not Selected");
		}
		return null;
	}

	@Override
	public void setBusinessSegment(BusinessSegment businesssegment) throws Exception{
		con=DBUtil.getConnection();
		String qry="insert into business_segment values(?,?)";
		PreparedStatement pstmt=con.prepareStatement(qry);
		pstmt.setString(1, businesssegment.getBus_Seg_Id());
		pstmt.setString(2, businesssegment.getBus_Seg_Name());
		int n=pstmt.executeUpdate();
		con.close();
		if(n==0){
			throw new InsuranceException(" Not inserted");
		}
		
		
	}

	@Override
	public List<PolicyQuestions> returnQuestions(String businessid) throws Exception{
		List<PolicyQuestions> list=new ArrayList<PolicyQuestions>();
		con=DBUtil.getConnection();
		String qry="select POL_QUES_ID,BUS_SEG_ID,POL_QUES_DESC,POL_QUES_ANS1,POL_QUES_ANS1_WEIGHTAGE,POL_QUES_ANS2,POL_QUES_ANS2_WEIGHTAGE,POL_QUES_ANS3,POL_QUES_ANS3_WEIGHTAGE from policy_questions where bus_seg_id=? ";
		PreparedStatement pstmt=con.prepareStatement(qry);
		pstmt.setString(1, businessid);
		ResultSet rst=pstmt.executeQuery();
		while(rst.next()){
			PolicyQuestions questions=new PolicyQuestions();
			questions.setPol_Ques_Id(rst.getString("pol_ques_id"));
			questions.setBus_Seg_Id(rst.getString("bus_seg_id"));
			questions.setPol_Ques_Desc(rst.getString("pol_ques_desc"));
			questions.setPol_Ques_Ans1(rst.getString("pol_ques_ans1"));
			questions.setPol_Ques_Ans1_weightage(rst.getInt("pol_ques_ans1_weightage"));
			questions.setPol_Ques_Ans2(rst.getString("pol_ques_ans2"));
			questions.setPol_Ques_Ans2_weightage(rst.getInt("pol_ques_ans2_weightage"));
			questions.setPol_Ques_Ans3(rst.getString("pol_ques_ans3"));
			questions.setPol_Ques_Ans3_weightage(rst.getInt("pol_ques_ans3_weightage"));
			list.add(questions);
		}
		return list;
	}

	@Override
	public List<Policy> returnPolicy(long accountnumber) throws Exception {
		con=DBUtil.getConnection();
		List<Policy> list=new ArrayList<Policy>();
		String qry="select policy_number,policy_premium,account_number from policy where account_number=?";
		PreparedStatement pstmt=con.prepareStatement(qry);
		pstmt.setLong(1, accountnumber);
		ResultSet rst=pstmt.executeQuery();
		while(rst.next()){
			Policy policy=new Policy();
			policy.setPolicyNumber(rst.getLong("policy_number"));
			policy.setPolicyPremium(rst.getDouble("policy_premium"));
			policy.setAccountnumber(rst.getLong("account_number"));
			list.add(policy);
		}
		return list;
	}

}
