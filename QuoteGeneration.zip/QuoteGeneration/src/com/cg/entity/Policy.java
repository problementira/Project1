package com.cg.entity;



public class Policy {
	private long policyNumber;
	private double policyPremium;

	private long accountnumber;

	public Policy() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Policy(long policyNumber, double policyPremium, long accountnumber) {
		super();
		this.policyNumber = policyNumber;
		this.policyPremium = policyPremium;
		this.accountnumber = accountnumber;
	}

	public long getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(long policyNumber) {
		this.policyNumber = policyNumber;
	}

	public double getPolicyPremium() {
		return policyPremium;
	}

	public void setPolicyPremium(double policyPremium) {
		this.policyPremium = policyPremium;
	}

	public long getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(long accountnumber) {
		this.accountnumber = accountnumber;
	}
	
	


	
}
