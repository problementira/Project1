package com.cg.entity;

public class UserRole {
	private String userName;
	private String passWord;
	private int roleCode;

	public UserRole() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserRole(String userName, String passWord, int roleCode) {
		super();
		this.userName = userName;
		this.passWord = passWord;
		this.roleCode = roleCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	public int getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(int roleCode) {
		this.roleCode = roleCode;
	}

}
