package com.cg.entity;


public class BusinessSegment 
{
	private String Bus_Seg_Id;
	
	private int Bus_Seg_Seq;
	
	private String Bus_Seg_Name;

	public BusinessSegment() {
		super();
	}

	public BusinessSegment(String bus_Seg_Id, int bus_Seg_Seq, String bus_Seg_Name) {
		super();
		Bus_Seg_Id = bus_Seg_Id;
		Bus_Seg_Seq = bus_Seg_Seq;
		Bus_Seg_Name = bus_Seg_Name;
	}

	public String getBus_Seg_Id() {
		return Bus_Seg_Id;
	}

	public void setBus_Seg_Id(String bus_Seg_Id) {
		Bus_Seg_Id = bus_Seg_Id;
	}

	public int getBus_Seg_Seq() {
		return Bus_Seg_Seq;
	}

	public void setBus_Seg_Seq(int bus_Seg_Seq) {
		Bus_Seg_Seq = bus_Seg_Seq;
	}

	public String getBus_Seg_Name() {
		return Bus_Seg_Name;
	}

	public void setBus_Seg_Name(String bus_Seg_Name) {
		Bus_Seg_Name = bus_Seg_Name;
	}


	
	
}
